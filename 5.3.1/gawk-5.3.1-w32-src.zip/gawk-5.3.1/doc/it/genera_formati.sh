:
# questo script, eseguito in questa directory
# genera tutti i formati della documentazione gawk
# che si possono ricavare a partire
# da gawk.texi, nella directory ./manual
#
# si invoca lo script che genera i vari formati
#
./gendocs.sh gawk gawk
